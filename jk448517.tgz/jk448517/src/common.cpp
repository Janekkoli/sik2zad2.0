//
// Created by jan on 6/7/24.
//

#include "common.h"
#include <stdexcept>
#include <sys/types.h>
#include <sys/socket.h>
#include <cerrno>
#include <chrono>
#include <netdb.h>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include "err.h"
#include <iostream>
#include <arpa/inet.h>
#define BAD_DESCRIPTOR (-1)

uint16_t read_port(char const *string) {
    char *endptr;
    errno = 0;
    unsigned long port = strtoul(string, &endptr, 10);
    if (errno != 0 || *endptr != 0 || port > UINT16_MAX) {
        fatal("%s is not a valid port number", string);
    }
    return (uint16_t) port;
}

// Following two functions come from Stevens' "UNIX Network Programming" book.
// Read n bytes from a descriptor. Use in place of read() when fd is a stream socket.
ssize_t readn(int fd, void *vptr, size_t n) {
    ssize_t nleft, nread;
    char *ptr;

    ptr = (char*)vptr;
    nleft = n;
    while (nleft > 0) {
        if ((nread = read(fd, ptr, nleft)) < 0)
            return nread;     // When error, return < 0.
        else if (nread == 0)
            break;            // EOF

        nleft -= nread;
        ptr += nread;
    }
    return n - nleft;         // return >= 0
}

std::string readall(int fd) { //TODO maybe should wait until delimiter \n\r
    const size_t read_chunks = BUFFER_SIZE_READALL;
    char buffer[read_chunks];
    std::string result;
    ssize_t nread;
    while ((nread = read(fd, buffer, read_chunks) ) > 0) {
        result+=std::string(buffer, nread);
    }
    if(nread < 0 && errno != EAGAIN){
        syserr("readall"); //TODO samething to do here
    }
    return result;
}

// Write n bytes to a descriptor.
ssize_t writen(int fd, const char *vptr, size_t n, bool report) {
    if(report) reportF(fd, std::string(vptr, strlen(vptr)), false);
    ssize_t nleft, nwritten;
    const char *ptr;

    ptr = (char*)vptr;               // Can't do pointer arithmetic on void*.
    nleft = n;
    while (nleft > 0) {
        if ((nwritten = write(fd, ptr, nleft)) <= 0)
            return nwritten;  // error

        nleft -= nwritten;
        ptr += nwritten;
    }
    return n;
}
#define MAX_MESSAGE_SIZE 256




int send_IAM(int fd, const char *seat, bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[6] = {'I', 'A', 'M', *seat, '\r', '\n'};
    return writen(fd, buffer, 6, report);
}

int send_TOTAL(int fd, int score1, int score2, int score3, int score4, bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "TOTALN%dE%dS%dW%d\r\n", score1, score2, score3, score4);
    return writen(fd, buffer, strlen(buffer),report);
}

std::string readallBlocking(int fd) {
    char buffer[BUFFER_SIZE_READALL];
    std::string results;
    int n = 0;
    n = read(fd, buffer, BUFFER_SIZE_READALL);
    results += std::string(buffer,n);
    return results;
}

std::ostream & operator<<(std::ostream &os, PlayersSides side) {
    switch (side) {
        case N: os << 'N'; break;
        case E: os << 'E'; break;
        case S: os << 'S'; break;
        case W: os << 'W'; break;
        default: os << 'X'; break; // Handle None or any other invalid value
    }
    return os;
}

char toChar(const PlayersSides &side) {
    switch (side) {
        case N: return 'N';
        case E: return 'E';
        case W: return 'W';
        case S: return 'S';
        default: return 'X';
    }
}

PlayersSides operator++(PlayersSides &c) {
    switch (c) {
        case N:
            c = E;
            break;
        case E:
            c = S;
            break;
        case S:
            c = W;
            break;
        case W:
            c = N;
            break;
        default: return None;
    }
    return c;
}

PlayersSides operator--(PlayersSides &c) {
    switch (c) {
        case N:
            c = W;
            break;
        case E:
            c = N;
            break;
        case S:
            c = E;
            break;
        case W:
            c = S;
            break;
        default: return None;
    }
    return c;
}

PlayersSides operator+(PlayersSides c, int i) {
    for(int i2=1;i2<=i;i2++)++c;
    return c;
}

PlayersSides operator-(PlayersSides c, int i) {
    for(int i2=1;i2<=i;i2++)--c;
    return c;
}

int send_SCORE(int fd, int score1, int score2, int score3, int score4, bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "SCOREN%dE%dS%dW%d\r\n", score1, score2, score3, score4);
    return writen(fd, buffer, strlen(buffer),report);
}

int send_TAKEN(int fd, int trick_number, const char *cards, const char *winner_seat,bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "TAKEN%d%s%c\r\n", trick_number, cards, *winner_seat);
    return writen(fd, buffer, strlen(buffer),report);
}

int send_WRONG(int fd, int trick_number,bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[64];
    snprintf(buffer, 64, "WRONG%d\r\n", trick_number);
    return writen(fd, buffer, strlen(buffer),report);
}

int send_TRICK(int fd, int trick_number, const char *cards,bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "TRICK%d%s\r\n", trick_number, cards);
    return writen(fd, buffer, strlen(buffer),report);
}

int send_DEAL(int fd, int deal_type, const char first_seat, const std::string &cards,bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "DEAL%d%c%s\r\n", deal_type, first_seat, cards.c_str());
    return writen(fd, buffer, strlen(buffer),report);
}

int send_BUSY(int fd, const std::string &busy_seats,bool report) {
    if(fd<1) return BAD_DESCRIPTOR;
    char buffer[MAX_MESSAGE_SIZE];
    snprintf(buffer, MAX_MESSAGE_SIZE, "BUSY%s\r\n", busy_seats.c_str());
    return writen(fd, buffer, strlen(buffer),report);
}

PlayersSides fromChar(char c) {
    if(c=='N')return N;
    if(c=='E')return E;
    if(c=='S')return S;
    if(c=='W')return W;
    throw std::invalid_argument("Invalid seat");
}

std::vector<Card> cardStringToArray2(const std::string &cardsString) {
    //std::cout<<cardsString<<"set\n";
    std::string k;
    std::vector<Card> wyn;
    for(auto & c : cardsString){
        k+=c;
        if(c=='C' || c=='D' || c=='H' || c=='S'){
            //std::cout<<k<<"\n";
            try{wyn.emplace_back(k);}
            catch(std::invalid_argument &e){ return {};}
            k = "";
        }
    }
    return wyn;
}

void makeReport(char *sender_ip, uint16_t sender_port, char *receiver_ip, uint16_t receiver_port, std::string message) {
    std::cout<<"["<<sender_ip<<":"<<sender_port<<","<<receiver_ip<<":"<<receiver_port<<","<<"time here"<<"] "<<message;
}


void split_tricknum_rest(const std::string& content, int &trick_number, std::string &cards)  //splits trick number and cards
{
    sscanf(content.c_str(), "%d", &trick_number);
    if(trick_number/1000 > 0) {cards=content.substr(2, content.size()-2);trick_number/=100;} //4 digit number
    else if(trick_number/100 > 0 && trick_number%10==0) {cards=content.substr(1,content.size()-1); trick_number/=100;} //one digit trick number and card 10*
    else if(trick_number/100>0) {cards=content.substr(2, content.size()-2); trick_number/=10;} //two digit trick number and one digit card
    //two digit trick ???
    else if(trick_number/10>0 && (content[2]=='C' || content[2]=='H' || content[2]=='D' || content[2]=='S')) {cards=content.substr(1, content.size()-1); trick_number/=10;  } //one digit trick and card with number
    else if(trick_number/10>0) {cards=content.substr(2, content.size()-2);}
    //one digit trick
    else {cards=content.substr(1, content.size()-1);} //
    //std::cout<<"from split trick function: trick number - "<< trick_number<< " cards string - "<< cards<<"\n";
}

std::string timeReport() {
    auto now = std::chrono::system_clock::now();
    time_t in_time_t = std::chrono::system_clock::to_time_t(now);
    auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) %1000;

    std::stringstream time;
    time << std::put_time(std::localtime(&in_time_t), "%Y-%m-%dT%H:%M:%S");
    time << "." << std::setw(3) << std::setfill('0') << milliseconds.count();
    return time.str();
}

void reportF(int sockfd, const std::string &message, bool is_message_recived) {
    sockaddr_in reciver_addr{}, sender_addr{};
    socklen_t reciver_len = sizeof(reciver_addr);
    socklen_t sender_len = sizeof(sender_addr);

    // Get sender info
    if (getsockname(sockfd, (sockaddr *)&reciver_addr, &reciver_len) == -1) {
        syserr("getsockname");
    }

    // Get receiver info
    if (getpeername(sockfd, (sockaddr *)&sender_addr, &sender_len) == -1) {
        syserr("getpeername");
    }

    char server_ip[INET_ADDRSTRLEN];
    char client_ip[INET_ADDRSTRLEN];

    inet_ntop(AF_INET, &(reciver_addr.sin_addr), server_ip, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, &(sender_addr.sin_addr), client_ip, INET_ADDRSTRLEN);
    int server_port = ntohs(reciver_addr.sin_port);
    int client_port = ntohs(sender_addr.sin_port);
    if(is_message_recived)
        std::cout << "[" << client_ip << ":" << client_port << "," << server_ip << ":" << server_port << "," << timeReport() << "] " << message;
    else
        std::cout << "[" << server_ip << ":" << server_port << "," << client_ip << ":" << client_port << "," << timeReport() << "] " << message;

}
